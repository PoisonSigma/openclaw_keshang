# 官网地址：

https://openclaw.ai

# OpenClaw本质是：

> 一个 **开源AI Agent框架**，可以在本地运行并自动执行任务
>
> 

安装方法有GitHub 里面使用git clone 加上源码地址，这个不适合新手，下面推荐给大家使用 更简单的方法：

提前安装node.js

```
brew install node
```

如果发现brew不能用,需要安装Homebrew：

```
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

验证方法：

```
brew --version
```



mac打开终端下面是自动化脚本安装，我打开了vpn，并且运行了大概3次，成功，之前2次都中途失败，但是这个不需要动脑，他会自动确认你的系统并且安装：



```
curl -fsSL https://openclaw.ai/install.sh | bash
```

如果发现安装问题，直接复制给ai，按照提示一步步执行

出现下面问题，代表安装成功，选择yes，继续

![image-20260311181857484](./i/image-20260311181857484.png)

![image-20260311182132201](./i/image-20260311182132201.png)

